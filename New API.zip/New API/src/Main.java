import java.time.LocalDate;

public class Main {

    public static void main(String[] args) {

        GrafConfiguration cfg = new GrafConfiguration("txt.graf");

        System.out.println(cfg.isSet("Date"));
        for(String str : cfg.getStringList("id")) {
            System.out.println(str);
        }


    }
}
