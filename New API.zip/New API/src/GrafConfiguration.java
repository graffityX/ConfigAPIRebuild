import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class GrafConfiguration {

    private final SaveInfo saveInf = new SaveInfo();


    private String path = null;

    private HashMap<String, String> hash = new HashMap<>();

    public GrafConfiguration(String path) {

        try {

            this.path = path;

            File file = new File(path);

            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {

                String nextLn = scanner.nextLine();

                String[] array = nextLn.split(" : ");

                hash.put(array[0], array[1]);

            }

        } catch (IOException | ArrayIndexOutOfBoundsException e) {

            System.out.println("Ein Fehler ist aufgetreten! Überprüfe, ob die Config noch existiert und ob auch JEDE zeile nach dem Prinzip Key : Value aufgebaut ist!");
            return;

        }


    }

    public void close() {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(new File(path)));
            for (String key : hash.keySet()) {
                writer.write(key + " : " + hash.get(key) + "\n");
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void set(String id, String input) {
        hash = saveInf.saveInfo(hash, id, input);
    }

    public void set(String id, Integer input) {
        hash = saveInf.saveInfo(hash, id, String.valueOf(input));
    }

    public void set(String id, Boolean input) {
        hash = saveInf.saveInfo(hash, id, String.valueOf(input));
    }

    public void set(String id, LocalDate date) {
        hash = saveInf.saveInfo(hash, id, date.toString());
    }

    public void set(String id, UUID uuid) {
        hash = saveInf.saveInfo(hash, id, uuid.toString());
    }

    public void set(String id, Double d) {
        hash = saveInf.saveInfo(hash, id, d.toString());
    }

    public void set(String id, Float f) {
        hash = saveInf.saveInfo(hash, id, f.toString());
    }

    public void setArray(String id, String[] array) {
        hash = saveInf.saveArray(hash, id, array);
    }

    public String getString(String id) {
        if(unknownKey(id)) return null;
        return hash.get(id);
    }

    public Integer getInteger(String id) {
        if(unknownKey(id)) return null;
        return Integer.valueOf(hash.get(id));
    }

    public Boolean getBoolean(String id) {
        if(unknownKey(id)) return null;
        return Boolean.valueOf(hash.get(id));
    }

    public LocalDate getDate(String id) {
        if(unknownKey(id)) return null;
        return LocalDate.parse(hash.get(id));
    }

    public Double getDouble(String id) {
        if(unknownKey(id)) return null;
        return Double.valueOf(hash.get(id));
    }

    public Float getFloat(String id) {
        if(unknownKey(id)) return null;
        return Float.valueOf(hash.get(id));
    }

    public UUID getUUID(String id) {
        if(unknownKey(id)) return null;
        return UUID.fromString(hash.get(id));
    }

    public File getNumber(String id) {
        if(unknownKey(id)) return null;
        return new File(hash.get(id));
    }

    public ArrayList<String> getStringList(String id) {
        if(unknownKey(id)) return null;
        StringBuilder sb = new StringBuilder(hash.get(id));
        sb.delete(0, 1);
        sb.deleteCharAt(sb.length() - 1);
        String[] array = sb.toString().split(",");
        ArrayList<String> toReturn = new ArrayList<>();
        for(String str : array) {
            toReturn.add(str);
        }
        return toReturn;


    }

    public boolean isSet(String id) {
        return hash.containsKey(id);
    }


    private boolean unknownKey(String id) {
        if(!(hash.containsKey(id))) {
            System.out.println("Dieser Key ist dem Dokument nicht bekannt!");
            return true;
        } else return false;
    }




}




