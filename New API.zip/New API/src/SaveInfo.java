import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

public class SaveInfo {


    public HashMap<String, String> saveInfo(HashMap<String, String> hash, String id, String value) {


        hash.put(id, value);
        return hash;
    }

    public HashMap<String, String> saveArray(HashMap<String, String> hash, String id, String[] value) {

        String finalstring = "{";

        for(String str : value) {

            finalstring = finalstring + "," + str;
        }

        finalstring = finalstring + "}";

        hash.put("id", finalstring);

        return hash;
    }



}
